

<html>
<body>

<form action="handle.php" method="POST">  <!--  NOTE: action="form.php" determines where form data is sent. -->
    Name: <input type="text" name="name"><br>
    E-mail: <input type="text" name="email"><br>
    <input type="submit">
</form>

</body>
</html>

