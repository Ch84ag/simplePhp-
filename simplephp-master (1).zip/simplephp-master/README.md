
# Welcome to simplephp

[![Join the chat at https://gitter.im/inno-code/simplephp](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/inno-code/simplephp?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
simple php examples


